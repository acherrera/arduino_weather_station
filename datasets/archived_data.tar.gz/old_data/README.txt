
# This data was collected by the old sensor design. Would assume a higher
response time, and more effect due to the ground.

Old design was replace 20170331. The old data will be start as tar compression
for ease of storage
